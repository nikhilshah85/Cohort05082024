import logo from './logo.svg';
import './App.css';
import  Usestatedemo  from './hooks/usestatehook';
 import Timer  from './hooks/useeffecthook';
import Comments from './getusercomments';
import { useCallback, useMemo, useState } from 'react';
import Todos from './hooks/todos.js'
import expensiveCalculation from './hooks/expencsivecalculation.js';
import useFetch from './hooks/customhook.js';


// function App() {
//   return (
//     <div>
//       <h1> Knowing Hooks in React </h1>
//       {/* <Usestatedemo></Usestatedemo>
//       <hr/>
//       <Timer></Timer> */}
//       <Comments></Comments>
//     </div>
//   );
// }

//useCallBack 
// const App = () => {
//   const [count, setCount] = useState(0);
//   const [todos, setTodos] = useState([]);

//   const increment = () => {
//     setCount((c) => c + 1);
//   };
//   const addTodo = useCallback(() => {
//     setTodos((t) => [...t, "New Todo"]);
//   }, [todos]);

//   return (
//     <>
//       <Todos todos={todos} addTodo={addTodo} />
//       <hr />
//       <div>
//         Count: {count}
//         <button onClick={increment}>+</button>
//       </div>
//     </>
//   );
// };


// const App = () => {
//   const [count, setCount] = useState(0);
//   const [todos, setTodos] = useState([]);
//   const calculation = useMemo(() => expensiveCalculation(count), [count]); // expensiveCalculation(count);

//   const increment = () => {
//     setCount((c) => c + 1);
//   };
//   const addTodo = () => {
//     setTodos((t) => [...t, "New Todo"]);
//   };

//   return (
//     <div>
//       <div>
//         <h2>My Todos</h2>
//         {todos.map((todo, index) => {
//           return <p key={index}>{todo}</p>;
//         })}
//         <button onClick={addTodo}>Add Todo</button>
//       </div>
//       <hr />
//       <div>
//         Count: {count}
//         <button onClick={increment}>+</button>
//         <h2>Expensive Calculation</h2>
//         {calculation}
//       </div>
//     </div>
//   );
// };


const App = () => {
  const [data] = useFetch("https://jsonplaceholder.typicode.com/comments");

  return (
    <>
      {data &&
        data.map((item) => {
          return <p key={item.email}>{item.email}</p>;
        })}
    </>
  );
};

export default App;

import { render } from "@testing-library/react";
import { useState } from "react";

function Usestatedemo() {
   
    const [count, setCount] = useState(0);
    const [techList,addtechList] = useState(['Angular','React','Vue']);

    const [name, setName] = useState("Nikhil");

    const [appName,setAppName] = useState("React Hooks");
    const [employeeList,modifyEmployeeList] = useState([]);

    // addtechList()
    // {
    //     this.techList.push("Docker");
    // }
    return (
        <div>
            <h1>Count: {count}</h1>  
            <button onClick={() => setCount(count + 1)}>Click</button>   
            <ul>
                {techList.map((tech,index) => <li key={index}>{tech}</li>)}
            </ul>     

           <button onClick={() => addtechList([...techList, "Docker"])}>
                Add Docker
            </button>
        </div>
    )

   
}

export default Usestatedemo;
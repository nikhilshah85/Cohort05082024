import logo from './logo.svg';
import './App.css';
import Maleproducts from './mycomponents/maleproducts';
import Femaleproducts from './mycomponents/femaleproducts';
import Kidsproducts from './mycomponents/kidsproducts';

function App() {

  //this data from from rest calls / webapi calls, never hard coded
  var maleproducts= [];
 var femaleproducts= [];
 var kidproducts= [];
 var productList = [
    {pid:101, pName:'Tie', pCatergory:'Clothing', pPrice:100, pisAvailable:true, pUser:'Male'},
    {pid:102, pName:'Shoes', pCatergory:'Clothing', pPrice:200, pisAvailable:true, pUser:'Female'},
    {pid:103, pName:'Hair-band', pCatergory:'Clothing', pPrice:300, pisAvailable:true, pUser:'Female'},
    {pid:104, pName:'Makeup-powder', pCatergory:'Clothing', pPrice:400, pisAvailable:true, pUser:'Female'},
    {pid:105, pName:'Scooter', pCatergory:'Clothing', pPrice:500, pisAvailable:true, pUser:'Female'},
    {pid:106, pName:'Baby Jacket', pCatergory:'Clothing', pPrice:600, pisAvailable:true, pUser:'Kids'},
    {pid:107, pName:'Kids 1', pCatergory:'Clothing', pPrice:700, pisAvailable:true, pUser:'Kids'},
    {pid:108, pName:'Kids 2', pCatergory:'Clothing', pPrice:800, pisAvailable:true, pUser:'Kids'},
    {pid:109, pName:'Female 22', pCatergory:'Clothing', pPrice:900, pisAvailable:true, pUser:'Female'},
    {pid:110, pName:'Female 24', pCatergory:'Clothing', pPrice:1000, pisAvailable:true, pUser:'Female'},
    {pid:111, pName:'Female 898', pCatergory:'Clothing', pPrice:1100, pisAvailable:true, pUser:'Female'},
    {pid:112, pName:'Female 888', pCatergory:'Clothing', pPrice:1200, pisAvailable:true, pUser:'Female'},
    {pid:113, pName:'Female 25', pCatergory:'Clothing', pPrice:1300, pisAvailable:true, pUser:'Female'},
    {pid:114, pName:'Kids 456', pCatergory:'Clothing', pPrice:1400, pisAvailable:true, pUser:'Kids'},
    {pid:115, pName:'Tie', pCatergory:'Clothing', pPrice:1500, pisAvailable:true, pUser:'Male'},
    {pid:116, pName:'Male 110', pCatergory:'Clothing', pPrice:1600, pisAvailable:true, pUser:'Male'},
    {pid:117, pName:'Kidde 678', pCatergory:'Clothing', pPrice:1700, pisAvailable:true, pUser:'Kids'},
    {pid:118, pName:'Male guy', pCatergory:'Clothing', pPrice:1800, pisAvailable:true, pUser:'Male'},
  ]

  //segeragate data
 

  function segegrateProducts(){
    
    for(var i=0; i<productList.length; i++){
      if(productList[i].pUser == 'Male'){
        maleproducts.push(productList[i]);
      }else if(productList[i].pUser == 'Female'){
        femaleproducts.push(productList[i]);
      }else if(productList[i].pUser == 'Kids'){
        kidproducts.push(productList[i]);
      }
      // alert('Data has been segregated');
      console.log(maleproducts[0].pName);
    }
  }

  function giveMaleProducts(){
    return maleproducts;
  }

  /**
   *
   */
 

  return (
    <div>
      <h1> My Shopping App</h1>
      <button onClick={segegrateProducts()}>Segregate Products</button>
      segegrateProducts();
      <Maleproducts maleproducts={maleproducts} data={giveMaleProducts()}/>
      <Femaleproducts femaleproducts={femaleproducts}/>
      <Kidsproducts kidproducts={kidproducts}/>

    </div>
  );
}

export default App;

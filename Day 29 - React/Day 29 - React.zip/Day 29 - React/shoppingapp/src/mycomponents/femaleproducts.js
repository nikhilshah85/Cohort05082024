export default function Femaleproducts() {
    return (
        <div>
            <h1>Female Products</h1>
        </div>
    )
}
export default function Maleproducts(Props) {
    return (
        <div>
            <h1>Male Products</h1>
            {Props.data()}
          <h2>  { Props.maleproducts.pPrice} </h2>

            
        </div>
    )
}
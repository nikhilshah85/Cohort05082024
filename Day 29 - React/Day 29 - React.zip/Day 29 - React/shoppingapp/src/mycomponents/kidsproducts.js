export default function Kidsproducts() {
    return (
        <div>
            <h1>Kids Products</h1>
        </div>
    )
}
import logo from './logo.svg';
import './App.css';
import Employee from './mycomponents/employee';
import AppInfo from './mycomponents/appinfo';
import Accounts from './mycomponents/accounts';

function App() {
  //this data will come from rest calls

  var empObj = { empNo: 1001, empName: "Nikhil", empSalary: 8000 }
  var appName = "Learning React";

  function greet()
  {
    alert('Props are wonderfun');
  }

  return(
   
    <div>
      <h1> Hello and Welcome to Function based component</h1>
      <p> Hello once again</p>

      <hr/>

      <Employee applicationName={ appName } 
                developerName={empObj.empName}
                greetings={greet} ></Employee>

      <hr/>

      <AppInfo applicationName={ appName } 
               employeeNumber={empObj.empNo}
               greetings={greet} ></AppInfo>

      <hr/>

      <Accounts applicationName={ appName }
                paysalary={empObj.empSalary + 5000}
                greetings={greet} ></Accounts>

    </div>
  );
}

export default App;

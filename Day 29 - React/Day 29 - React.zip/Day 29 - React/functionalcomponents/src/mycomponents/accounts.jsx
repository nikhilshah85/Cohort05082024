export default function Accounts() {
    return (
        <div>
            <h1>Accounts Component</h1>
        </div>
    )
}

export default function AppInfo() {
    return (
        <div> 
            <h1>App Info</h1>

            <p>Version 1.0.0</p>
            <p> Developed By : Training team at Revature </p>
            <p> Copyright @ 2024   </p>
            <p> Team Strength : 23 Developers</p>
            <p> Is In Production : False</p>

        </div>
    )
}
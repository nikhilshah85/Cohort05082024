export default function Employee(Props) {
    
    var empNo = 1001;
    var empName = "Nikhil";
    var empSalary = 8000;

    function greetUser()
    {
        alert('Hello and welcome to function based component');
    }
    
    return (
        <div>
            <h2> App Name : { Props.applicationName } </h2>
            <h2> Star Developer : {Props.developerName } </h2>
            <button onClick={ Props.greetings }>Greet</button>

{/*             
            <h1>Employee Component</h1>
            <h3> Employee Number : { empNo } </h3>
            <h3> Employee Name : { empName } </h3>
            <h3> Employee Salary : { empSalary }   </h3>
            <h3> Bonuds : { empSalary * 0.1 }</h3>
            <h3> Addition of fav Numbers : { 10 + 20 }  </h3>
            <h3> Salary Grade : { empSalary > 12000 ? "Excellent" : "Average" }</h3>
         */}
        {/* <button onClick={ greetUser }>Greet</button> */}

        </div>  
    )
}


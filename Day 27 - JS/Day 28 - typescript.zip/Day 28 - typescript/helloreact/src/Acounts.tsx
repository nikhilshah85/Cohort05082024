import { Component } from "react";
import React from "react";
class Account extends Component {

    accountList:any[] = [
        {accNo:101, accName:'Nik',accType:'Savings',accBalance:10000,accIsActive:true},
        {accNo:102, accName:'Alex',accType:'Savings',accBalance:20000,accIsActive:true},
        {accNo:103, accName:'Rommy',accType:'Checking',accBalance:40000,accIsActive:false},
        {accNo:104, accName:'Micheal',accType:'Savings',accBalance:10000,accIsActive:true},
        {accNo:105, accName:'Jordan',accType:'Savings',accBalance:7000,accIsActive:true},
        {accNo:106, accName:'Ben',accType:'Savings',accBalance:900,accIsActive:true},
        {accNo:107, accName:'Mary',accType:'Savings',accBalance:12000,accIsActive:false},
        {accNo:108, accName:'Elena',accType:'Checking',accBalance:80000,accIsActive:true},
        {accNo:109, accName:'Taylor',accType:'Savings',accBalance:1000,accIsActive:true},
        {accNo:110, accName:'Sara',accType:'Savings',accBalance:100,accIsActive:false},
        {accNo:111, accName:'Alex',accType:'Checking',accBalance:40000,accIsActive:true},
    ]

    /**
     *
     */
    constructor(props:any) {
        super(props);
        this.addNewProduct = this.addNewProduct.bind(this);
        
    }

    displayTotalAccounts() {

        return this.accountList.length;
    }

    addNewProduct() {
        var newproduct:any = {accNo:112, accName:'Angel',accType:'Loan',accBalance:90000,accIsActive:false}
        this.accountList.push(newproduct);
    }


    render() {
        return (
            <div>
                <h1> Account Component </h1>

                <table>
                    <tr>
                        <th>Account Number</th>
                        <th>Account Name</th>
                        <th>Account Type</th>
                        <th>Account Balance</th>
                        <th>Account Is Active</th>
                    </tr>


                    {this.accountList.map((a) => <tr>
                        <td>{a.accNo}</td>
                        <td>{a.accName}</td>
                        <td>{a.accType}</td>
                        <td>{a.accBalance}</td>
                        <td><input type="checkbox" checked={a.accIsActive} /></td>
                    </tr>)}
                    

                </table>
                        <button onClick={() => this.addNewProduct()}>Add New Product</button>
                <h3> Total Accounts : {this.displayTotalAccounts()}</h3>
            </div>
        );
    }
}
export default Account;
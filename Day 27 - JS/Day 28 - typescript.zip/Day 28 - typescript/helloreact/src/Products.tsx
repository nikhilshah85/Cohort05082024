import React from 'react';
import { Component } from 'react';

class Products extends Component {
    
    componentName:string = "Products";
    productsList:string[] = ["Apple", "Banana", "Orange", "Mango", "Grapes", "Pineapple"];
    
    render() {


        return (
            <div>
                <h1>{this.componentName}</h1>
                <ul>
                    {this.productsList.map((p) => <li>{p}</li>)}
                </ul>

                <select>
                    {this.productsList.map((p) => <option>{p}</option>)}
                </select>

              
                    {this.productsList.map((p) =>  <span>  <input type="checkbox"/> {p} </span> )}
               

            </div>
        );
    }
}
export default Products;
import logo from './logo.svg';
import './App.css';
import Employee from './Employee.tsx';
import Products from './Products.tsx';
import Account from './Acounts.tsx';

function App() {
  return (
    <div>
      
      
      <h1> Hello and Welcome To React</h1>
      <p> This is going to be very exciting</p>

<hr/>
    <Account></Account>

{/* <Products></Products> 
<hr/>
      <Employee></Employee> */}
    
    

        
    
    </div>
    
       
  );
}

export default App;

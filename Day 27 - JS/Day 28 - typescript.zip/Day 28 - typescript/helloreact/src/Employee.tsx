import { Component } from 'react';
import React from 'react';
export default class Employee extends Component 
{
    //values are hardcoded as of now, but it can come from REST api call
    empName:string = "Nikhil";
    empEmail:string = "nikhil@hotmail.com";
    empDesignation:string = "Software Engineer";
    empSalary:number = 100000;
    empAge:number = 25;
    empCity:string = "Mumbai";
    empIsPermenant:boolean = true;

    calculateBonus():number
    {
        return this.empSalary * 10 / 100;
    }

    render(){
        return (
             <div style={{backgroundColor:"purple"}}>
                <h1> Employee Component </h1>
                <h4> Employee Name : {this.empName}  </h4>
                <h4> Employee Email : {this.empEmail}  </h4>
                <h4> Employee Designation : {this.empDesignation}  </h4>
                <h4> Employee Salary : {this.empSalary}  </h4>
                <h4> Employee Age : {this.empAge}  </h4>
                <h4> Employee City : {this.empCity}  </h4>
                <h4> Employee Is Permenant : {this.empIsPermenant}  </h4>
                <h4> Employee Bonus : {this.calculateBonus()}  </h4>
            </div>
        );
    }


}
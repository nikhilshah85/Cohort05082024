import { useState, useEffect } from "react"

export default function  Comments(){

    const [comments,setComments] = useState([])

    useEffect(() => {

        fetch("https://jsonplaceholder.typicode.com/comments")
            .then(responseType => responseType.json())
            .then(data => setComments(data))
            .catch(error => console.log(error))}
    ,[])

    return(
        <div>
            <h1>Comments</h1>
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Post Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Body</th>
                    </tr>
                </thead>
                <tbody>
                {comments.map((comment) => comment.postId === 1 &&
                        <tr key={comment.id}>
                            <td>{comment.postId}</td>
                            <td>{comment.name}</td>
                            <td>{comment.email}</td>
                            <td>{comment.body}</td>
                        </tr>
                    )}
                </tbody>
            </table>

        </div>
    )
}